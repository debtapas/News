<?php

if ( ! function_exists( 'vp_metabox' ) ) {
	function vp_metabox() {}
}
