<div class="meta-header">
    <div class="meta-header-content"><?php echo esc_html($head_info['label']); ?></div>
</div>
