SubtlePatterns
===============

All the patterns from www.subtlepatterns.com - including the famous Photoshop .pat file

If you need Base64 versions of the patterns you can use this generator:
http://www.greywyvern.com/code/php/binary2base64


Subtle Patterns is created and curated by Atle Mo.
The original author of the patterns are credited on subtlepatterns.com

Subtle Patterns by Subtle Patterns is licensed under a Creative Commons Attribution-ShareAlike 3.0 Unported License.
Based on work at subtlepatterns.com.
Permissions beyond the scope of this license may be available upon contact.
A project by Atle Mo.

Subtle Patterns and www.subtlepatterns.com © 2013 Atle Mo.

===============

ENJOY!
