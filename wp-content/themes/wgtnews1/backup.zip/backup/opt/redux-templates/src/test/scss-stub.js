/**
 * This stub is needed to ignore SCSS files within JS files for testing.
 *
 * @see https://github.com/facebook/jest/issues/870
 */
module.exports = {}
