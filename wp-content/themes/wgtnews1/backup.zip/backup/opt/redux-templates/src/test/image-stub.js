/**
 * This stub is needed to ignore images within JS files for testing.
 *
 * @see https://github.com/facebook/jest/issues/870
 */
module.exports = {}
